from setuptools import setup, find_packages

setup(name='azopencensus', version='1.0', packages=find_packages())